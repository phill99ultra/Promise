const options = [
    {value: -1, label: 'Nu stiu'},
    {value: 0, label: 'Chuck Norris'},
    {value: 1, label: 'Supreman'}
]
const buildForm = (id,  options) => {
    var myForm = document.getElementById('vote');
    var h2 = document.createElement('h2')
        h2.innerText = 'Pentru cine votezi?'
    myForm.appendChild(h2)
    options.forEach(option => {
        var element = document.createElement('input')
            element.type = 'radio'
            element.name = 'candidate'
            element.value = option.value
        myForm.appendChild(element)
        var text = document.createElement('label')
            text.innerText = option.label
        myForm.appendChild(text)
        var br = document.createElement('br')
        myForm.appendChild(br)
    });
    var hr = document.createElement('hr')
    myForm.appendChild(hr)
    var button = document.createElement('button')
        button.type = 'submit'
        button.innerText = 'Send'
    myForm.appendChild(button)
    button.onclick = (event) => {
        event.preventDefault();
        try {
            const vote = document.querySelector('#vote input:checked').value;
        } catch(exception) {
            alert('Nu ati ales candidatul!')
        }
        alert(vote)
    }
} 
buildForm('vote', options)