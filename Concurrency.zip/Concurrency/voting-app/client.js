const options = [
  { value: -1, label: 'Nu știu' },
  { value: 0, label: 'Chuck Norris' },
  { value: 1, label: 'Supreman' }
];
const buildForm = (id, options) => {
  const myForm = document.querySelector('.vote');
  myForm.innerHTML = `<h2>Pentru cine votezi?</h2><hr>`;
  options.forEach(option => {
    const element = `<input type="radio" name="candidate" value="${option.value}"><label>${option.label}</label><br>`;
    myForm.innerHTML += element;
  });
  myForm.innerHTML += `<input class="vote__form check__name" type="text" placeholder="Nume/Prenume" name="name" required>
                      <br>
                      <input class="vote__form" type="number" placeholder="Nr.Contact" name="phone" required>
                      <hr>
                      <button class="vote__button" type="submit" method="">Send</button>`;
  document.querySelector('.vote__button').onclick = event => {
    event.preventDefault();
    try {
      var vot = document.querySelector('input[name="candidate"]:checked').value;
    } catch (exception) {
      if (document.querySelector('input[name="candidate"]').checked == false) {
        alert('Nu ați ales candidatul!');
      }
    }
    try {
      var name = document.querySelector('.check__name').value,
        letters = /^[A-Za-z]+$/;
    } catch (exception) {
      if (!name.match(letters)) {
        // throw new SyntaxError('InvalidFullName');
        alert('dada');
      }
    }
  };
  alert(name);
};
buildForm('vote', options);
