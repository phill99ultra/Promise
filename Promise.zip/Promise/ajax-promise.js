const API_URL = 'http://zip-api.com/json'
new Promise((resolve, reject) => {
    console.log(5, 'Waiting')
    
    // asynchronous
    var xhr = new XMLHttpRequest();
    xhr.open('GET', API_URL)
    xhr.send()
    xhr.onload = () => {
        resolve(xhr.responseText)
    }
  
    xhr.onerror = () => {
        reject(xhr.responseText)
    }

}).then((message) => {
    //logic to success
    console.log(6, 'Code resolved', message)
}).catch((message) => {
    //logic for errors
    console.log(7, 'Code rejected', message)
})