// var p = new Promise(() => {
    
// })
// console.log(1,p)

// var p = new Promise((resolve) => {
//     resolve()
// })
// console.log(2,p)

// var p = new Promise((resolve, reject) => {
//     reject()
// })
// console.log(3,p)

// new Promise((resolve) => {
//     console.log(5, 'Waiting')
//     setTimeout(() => {
//         resolve('Done!')
//     }, 1500)
// }).then((message) => {
//     console.log(6, 'Code after Promise', message)
// })

new Promise((resolve, reject) => {
    console.log(5, 'Waiting')
    setTimeout(() => {
        Math.random() > 0.5 ? resolve({}) : reject('Ooops!');        
    }, 1500)
}).then((message) => {
    //logic to success
    console.log(6, 'Code resolved', message)
}).catch((message) => {
    //logic for errors
    console.log(7, 'Code rejected', message)
})