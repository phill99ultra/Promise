const API_URL = 'http://ip-api.com/json'

// functia primeste o adresa si returneaza o promisiune care asteapta datele de pe adresa data
const ajaxGet = (url) => {
    return new Promise((resolve, reject) => {
        var xhr = new XMLHttpRequest();
    xhr.open('GET', API_URL)
    xhr.send()
    xhr.onload = () => {
        resolve(xhr.responseText)
    }
  
    xhr.onerror = () => {
        reject(xhr.responseText)
    }
        // asynchronous
        
    })
   
}
ajaxGet(API_URL)
.then((message) => {
    //logic to success
    console.log(6, 'Code resolved', message)
}).catch((message) => {
    //logic for errors
    console.log(7, 'Code rejected', message)
})