const http = require('http')
const fs = require('fs')
const server = http.createServer((req, res) => {
    let data = fs.readFileSync('./data/image.json')
    console.log(data)
    // data -> Buffer -> String (JSON) -> Object
    // String (JSON) <- Object
    let data_obj = JSON.parse(data.toString())
    // add a new prop
    data_obj.image = fs.readFileSync('./data/image.jpg')
    // console.log(data_obj)
    res.setHeader('Content-type', 'application/json')
    res.setHeader("Access-Control-Allow-Origin", "*"); 
    res.setHeader("Access-Control-Allow-Headers", "Origin, X-Requested-With, Content-Type, Accept");
    res.end( JSON.stringify(data_obj)) // problem in this line
})

server.listen(3000)