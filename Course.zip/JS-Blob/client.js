const load = () => {
    // CORS policy 
    fetch('http://localhost:3000')
                    .then(response => {
                        // console.log(response)
                        return response.json()
                    })
                    .then(json => {
                        const container = $('#result')
                        container.append(`<h1>${json.title}</h1>`)
                        container.append(`<p>${json.author}</p>`)
                        container.append(`<p>${json.data}</p>`)
                        // let img_data = Buffer.from(json.image.data)
                        // let srcImg = `./data/image.jpg${img_data.toString('base64')}`
                        container.append(`<img src="" alt="myImage">`)
                        console.log( json )
                        console.log( typeof json )
                    })
}