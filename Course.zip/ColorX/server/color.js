// module
const Vibrant = require("node-vibrant");

exports.getPalette = image_name => {
  let vibrant = new Vibrant(`../public/${image_name}`);
  return vibrant.getPalette();
  // .then((palette) => console.log(palette))
};
