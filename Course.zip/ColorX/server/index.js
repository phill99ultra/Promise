const color = require("./color");
const fs = require("fs");
const http = require("http");

// color.getPalette('image.jpg')
//     .then(palette => { // 1. convert to json
//         console.log(palette)
//         return {
//             json: JSON.stringify(palette),
//             // image_name:
//         }
//     })
//     .then(pallete => {
//         // 1. create file myimg.jpg.json
//         // 2. save file to 'pallete'
//         fs.writeFile('../public/data_image/image.jpg.json', pallete.json)
//     .then(() => {
//         // dupa save
//         console.log('done')
//         })
//     })
const server = http.createServer((req, res) => {
  if ((result = req.url.match(/\/image\/.*\.(?:jpg)/))) {
    try {
      let result = fs.readFileSync(`../public/${result[1]}`);
      res.end(result);
    } catch (e) {
      res.end("not found");
    }
  } else if (req.url == "/") {
    try {
      let result = fs.readFileSync(`../public/index.html`);
      res.end(result);
    } catch (e) {
      res.end("not found");
    }
  } else if ((result = req.url.match(/\/data\/(.*\.json)/))) {
    try {
      let data = fs.readFileSync(`../public/data_image/${result[1]}`);
      console.log(result);
      res.end(data);
    } catch (e) {
      res.end("Not Found");
    }
  } else {
    res.end("NotFound!");
  }
});

server.listen(4477);
