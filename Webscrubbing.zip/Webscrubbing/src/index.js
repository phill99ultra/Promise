// http < --- core
// https < --- core
// HTML parser jsdom/npm
import {JSDOM} from 'jsdom'
import fs from 'fs'
import https from 'https'

let html_code = ''

https.get('https://www.torrentsmd.com/', (res) => {
  console.log('statusCode:', res.statusCode);
  console.log('headers:', res.headers);

  res.on('data', (d) => {
    process.stdout.write(d);
    html_code += d
  });
  res.on('end', () => {
    const {document} = (new JSDOM(html_code.toString(), {
        url: "https://www.torrentsmd.com/",    
    })).window
    var c = document.getElementsByTagName('p')
    for(var i in c) {
        console.log(c[i])
    }
  });

}).on('error', (e) => {
  console.error(e);
});


// const {document} = (new JSDOM('',{
//     url: "https://ip-api.com/",    
//   })).window

//   console.log(document.title)